<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Hashing\BcryptHasher;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
   /*  public function dashboardA(){
      $admins = Admin::all();
      return view('dashboard',['admins'=>$admins]);

    }*/

    public function loginA(Request $request){

$validator = Validator::make($request->all(),[
       
       'email'=>'required',
       'password'=>'required',]);
    
    if ($validator->fails()) {
        return array(
         'error'=>true,
         'message'=>$validator->errors()->all()
        );
    }

$admin = User::where('email',$request->input('email'))->first();
if(count((array)$admin)){

    if (($request->input('password')==$admin->password)) {

        unset($admin->password);
         if ('User'==$admin->profil) {
        //return redirect('/dashboardadmin');
     //   return array('error'=>false,'admin'=>$admin);
        return redirect('/dash');}
        else{return array('error'=>true,'message'=>'profil not allowed');}
    }
    else{

        return array('error'=>true,'message'=>'invalid password');
    }
}else{
    return array('error'=>true,'message'=>'User not found');
}

}
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function dashboard()
    {
        //
      $admins = User::all();
      return view('dashboard',['admins'=>$admins]);
    }

    public function readA($id_user){
        $admins = User::find($id_user);
        //return $id;
        return view('readUser',['admins'=>$admins]);
        
    }
     public function createU(Request $request){
    $validator = Validator::make($request->all(),[
       'nom'=>'required',
       'prenom'=>'required',
       'email'=>'required|unique:user',
       'password'=>'required|min:6',
       'profil'=>'required']);
    
    if ($validator->fails()) {
        return array(
         'error'=>true,
         'message'=>$validator->errors()->all()
        );
    }

    $admin=new User();
    $admin->nom=$request->input('nom');
    $admin->prenom=$request->input('prenom');
    $admin->email=$request->input('email');
    $admin->password=$request->input('password');
    $admin->profil=$request->input('profil');

    $admin->save();

    unset($admin->password);

    return redirect('/dash');

  }


public function deleteU($id_user){
    User::where('id_user',$id_user)
    ->delete();
    return redirect('/dash');
    }

 public function editU(Request $request, $id_user){
      
        $validator = Validator::make($request->all(),[
       'nom'=>'required',
       'prenom'=>'required',
       'email'=>'required',
       'password'=>'required|min:6',
       'profil'=>'required']);

        $data = array(
       'nom'=>$request->input('nom'),
       'prenom'=>$request->input('prenom'),
       'email'=>$request->input('email'),
       'password'=>$request->input('password'),
       'profil'=>$request->input('profil'),
        );
        User::where('id_user',$id_user)
        ->update($data);
        return redirect('/dash');
         
    } 

 public function updateU($id_user){
        $users = User::find($id_user);
        return view('editUser',['users'=>$users]);
        /* check 
        echo '<pre>';
        print_r($articles);
        echo "</pre>";
        exit();*/       
    } 

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        //
    }
}
