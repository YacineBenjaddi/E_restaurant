<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Avi
 * 
 * @property int $id_avis
 * @property int $id_user
 * @property int $id_restaurant
 * @property int $note
 * @property string $avis
 * 
 * @property Restaurant $restaurant
 * @property User $user
 *
 * @package App\Models
 */
class Avi extends Model
{
	protected $table = 'avis';
	protected $primaryKey = 'id_avis';
	public $timestamps = false;

	protected $casts = [
		'id_user' => 'int',
		'id_restaurant' => 'int',
		'note' => 'int'
	];

	protected $fillable = [
		'id_user',
		'id_restaurant',
		'note',
		'avis'
	];

	public function restaurant()
	{
		return $this->belongsTo(Restaurant::class, 'id_restaurant');
	}

	public function user()
	{
		return $this->belongsTo(User::class, 'id_user');
	}
}
