<?php
include 'conn.php';

$result =array();

$queryResult=$connect->query("SELECT * FROM comments  Order by rating DESC ");

$result=array();

while ($fetchData=$queryResult->fetch_assoc()) {
	# code...
	$result[]=$fetchData;
}
echo json_encode($result);

?>