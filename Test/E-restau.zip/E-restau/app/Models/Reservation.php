<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Reservation
 * 
 * @property int $id_Reservation
 * @property int $id_user
 * @property int $id_restaurant
 * @property string $heure
 * @property Carbon $date
 * 
 * @property User $user
 * @property Restaurant $restaurant
 *
 * @package App\Models
 */
class Reservation extends Model
{
	protected $table = 'reservation';
	protected $primaryKey = 'id_Reservation';
	public $timestamps = false;

	protected $casts = [
		'id_user' => 'int',
		'id_restaurant' => 'int'
	];

	protected $dates = [
		'date'
	];

	protected $fillable = [
		'id_user',
		'id_restaurant',
		'heure',
		'date'
	];

	public function user()
	{
		return $this->belongsTo(User::class, 'id_user');
	}

	public function restaurant()
	{
		return $this->belongsTo(Restaurant::class, 'id_restaurant');
	}
}
